/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sis_laboratorios_pryintegrador;

import views.login_panel;

/**
 *
 * @author Desktop
 */
public class Sis_laboratorios_pryIntegrador {

    public static void main(String[] args) {
        new login_panel().setVisible(true);
    }
}
